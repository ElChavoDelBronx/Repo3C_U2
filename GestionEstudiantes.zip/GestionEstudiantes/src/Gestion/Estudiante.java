package Gestion;

public class Estudiante extends Persona {
    double promedio;

    public Estudiante(String nombre, String email, double promedio) {
        super(nombre, email);
        this.promedio = promedio;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String getEmail() {
        return email;
    }

    public String toString() {
        return "Estudiante: " + getNombre() + ", Email: " + getEmail() + ", Promedio: " + promedio;
    }

}
