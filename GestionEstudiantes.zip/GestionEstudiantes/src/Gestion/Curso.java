package Gestion;

public class Curso {
    String codigo;
    String nombre;
    private Estudiante[] inscritos;

    public Curso(String codigo, String nombre, Estudiante[] inscritos) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.inscritos = inscritos;
    }

    public Curso(String codigo, String nombre, int capacidad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.inscritos = new Estudiante[capacidad];
    }

    public boolean inscribir(Estudiante e) {
        for (int i = 0; i < inscritos.length; i++) {
            if (inscritos[i] == null) {
                inscritos[i] = e;
                return true;
            }
        }
        return false;
    }

    public double calcularPromedioGrupo() {
        double suma = 0;
        int contador = 0;
        for (Estudiante e : inscritos) {
            if (e != null) {
                suma += e.getPromedio();
                contador++;
            }
        }
        if (contador == 0) return 0;
        return suma / contador;
    }


}
