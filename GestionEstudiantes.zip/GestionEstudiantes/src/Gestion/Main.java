package Gestion;

public class Main {
    public static void main(String[] args) {
        Curso curso1 = new Curso("1", "Espanol", 3);
        Estudiante e1 = new Estudiante("Juan", "Juan@gmail.com", 9);
        Estudiante e2 = new Estudiante("Jazmin", "Jazmin@gmial.com", 8);
        Estudiante e3 = new Estudiante("Raul", "Raul@gmial.com", 10);
        Estudiante e4 = new Estudiante("Damian", "Damian@gmial.com", 10);

        boolean inscrito1 = curso1.inscribir(e1);
        System.out.println("El estudiante fue inscrito: " + inscrito1);

        boolean inscrito2 = curso1.inscribir(e2);
        System.out.println("El estudiante fue inscrito: " + inscrito2);

        boolean inscrito3 = curso1.inscribir(e3);
        System.out.println("El estudiante fue inscrito: " + inscrito3);

        boolean inscrito4 = curso1.inscribir(e4);
        System.out.println("El estudiante fue inscrito: " + inscrito4);

        System.out.println("Promedio del grupo: " + curso1.calcularPromedioGrupo());

    }
}
