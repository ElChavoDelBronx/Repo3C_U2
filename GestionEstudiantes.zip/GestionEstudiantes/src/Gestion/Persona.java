package Gestion;

public abstract class Persona {
    protected String nombre;
    protected String email;

    public abstract String getNombre();
    public abstract String getEmail();

    public Persona(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }
}
