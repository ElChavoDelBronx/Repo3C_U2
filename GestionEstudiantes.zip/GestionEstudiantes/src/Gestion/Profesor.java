package Gestion;

public class Profesor extends Persona {

    public Profesor(String nombre, String email) {
        super(nombre, email);

    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String getEmail() {
        return email;
    }

    public String toString() {
        return "Profesor: " + getNombre() + ", Email: " + getEmail();
    }
}
